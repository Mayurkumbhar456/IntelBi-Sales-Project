# Databricks notebook source
# ADLS + SQL Config
storage_account = "adlssalesprojectmk"
storage_key = "BnXXyx9cM7zzuxKIJlG61xqTEDLlH9FbUU169T0qEPk0qWvYYkNarxvniuxWFXFZQb1w8LAfzAYy+AStFRbHUw=="

spark.conf.set(
    f"fs.azure.account.key.{storage_account}.dfs.core.windows.net",
    storage_key
)

sql_server   = "sqlserver-salesproject-mk.database.windows.net"
sql_database = "ASQL-SalesProject-MK"
sql_user     = "sqladminmk"
sql_password = "Mayur@29"

jdbc_url = (
    f"jdbc:sqlserver://{sql_server}:1433;"
    f"database={sql_database};"
    f"encrypt=true;"
    f"trustServerCertificate=false;"
    f"hostNameInCertificate=*.database.windows.net;"
    f"loginTimeout=30;"
)

jdbc_props = {
    "user"     : sql_user,
    "password" : sql_password,
    "driver"   : "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}

from pyspark.sql import functions as F
from pyspark.sql.window import Window

print("Config ready!")

# COMMAND ----------

# Truncate ALL integration tables before reload
conn = spark._jvm.java.sql.DriverManager.getConnection(
    jdbc_url,
    jdbc_props["user"],
    jdbc_props["password"]
)
stmt = conn.createStatement()
stmt.execute("TRUNCATE TABLE integration.TBL_FACT_SALES")
stmt.execute("TRUNCATE TABLE integration.TBL_FACT_INVENTORY")
stmt.execute("TRUNCATE TABLE integration.TBL_DIM_ORDER")
stmt.execute("TRUNCATE TABLE integration.TBL_DIM_PRODUCT")
stmt.execute("TRUNCATE TABLE integration.TBL_DIM_ORDER_METHOD_LKP")
stmt.execute("TRUNCATE TABLE integration.TBL_DIM_RETURN_REASON_LKP")
stmt.execute("TRUNCATE TABLE integration.TBL_DIM_COUNTRY_LKP")
stmt.execute("TRUNCATE TABLE integration.TBL_DIM_WAREHOUSE_LKP")
stmt.execute("TRUNCATE TABLE integration.TBL_DIM_RETAILER_LKP")
stmt.execute("TRUNCATE TABLE integration.TBL_DIM_PRODUCT_NAME_LKP")
stmt.close()
conn.close()

# COMMAND ----------

# SCD1 helper — Truncate and reload
def scd1_load(df_source, target_table, business_key):

    # Truncate target table first using JDBC
    conn = spark._jvm.java.sql.DriverManager.getConnection(
        jdbc_url,
        jdbc_props["user"],
        jdbc_props["password"]
    )
    stmt = conn.createStatement()
    stmt.execute(f"TRUNCATE TABLE {target_table}")
    stmt.close()
    conn.close()

    # Add SCD columns to source
    df_source_scd = df_source \
        .withColumn("BEGIN_EFFECTIVE_DATE", F.current_timestamp()) \
        .withColumn("END_EFFECTIVE_DATE", F.lit("2099-12-31").cast("timestamp")) \
        .withColumn("VERSION_NUM", F.lit(1)) \
        .withColumn("CHANGE_INFO", F.lit(None).cast("string")) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Append fresh data
    df_source_scd.write.jdbc(
        url=jdbc_url,
        table=target_table,
        mode="append",
        properties=jdbc_props
    )

    count = df_source_scd.count()
    print(f"{target_table} — Loaded: {count}")

# COMMAND ----------

# SCD2 helper — Insert new, Expire old and insert new version
def scd2_load(df_source, target_table, business_key, compare_cols):

    # Read existing integration table
    df_target = spark.read.jdbc(
        url=jdbc_url,
        table=target_table,
        properties=jdbc_props
    )

    if df_target.count() == 0:
        # First load — insert all as new
        df_new = df_source \
            .withColumn("BEGIN_EFFECTIVE_DATE", F.current_timestamp()) \
            .withColumn("END_EFFECTIVE_DATE", F.lit("2099-12-31").cast("timestamp")) \
            .withColumn("VERSION_NUM", F.lit(1)) \
            .withColumn("CHANGE_INFO", F.lit(None).cast("string")) \
            .withColumn("DW_INSERT_DT", F.current_timestamp()) \
            .withColumn("DW_UPDATE_DT", F.current_timestamp())

        df_new.write.jdbc(
            url=jdbc_url,
            table=target_table,
            mode="append",
            properties=jdbc_props
        )
        print(f"{target_table} — New: {df_new.count()}, Changed: 0")

    else:
        # Subsequent load — detect changes
        df_active = df_target.filter(
            F.col("END_EFFECTIVE_DATE") == F.lit("2099-12-31").cast("timestamp")
        )

        # New records — not in target at all
        df_new = df_source.join(
            df_active.select(business_key),
            on=business_key,
            how="left_anti"
        ).withColumn("BEGIN_EFFECTIVE_DATE", F.current_timestamp()) \
         .withColumn("END_EFFECTIVE_DATE", F.lit("2099-12-31").cast("timestamp")) \
         .withColumn("VERSION_NUM", F.lit(1)) \
         .withColumn("CHANGE_INFO", F.lit(None).cast("string")) \
         .withColumn("DW_INSERT_DT", F.current_timestamp()) \
         .withColumn("DW_UPDATE_DT", F.current_timestamp())

        # Detect changed records using subtract
        src_cols = [business_key] + compare_cols
        df_changed_keys = df_source.select(src_cols) \
            .subtract(df_active.select(src_cols)) \
            .select(business_key)

        # Expire old active records for changed keys
        df_to_expire = df_active.join(
            df_changed_keys, on=business_key, how="inner"
        ).withColumn("END_EFFECTIVE_DATE", F.current_timestamp()) \
         .withColumn("DW_UPDATE_DT", F.current_timestamp())

        # New versions of changed records
        df_new_version = df_source.join(
            df_changed_keys, on=business_key, how="inner"
        ).withColumn("BEGIN_EFFECTIVE_DATE", F.current_timestamp()) \
         .withColumn("END_EFFECTIVE_DATE", F.lit("2099-12-31").cast("timestamp")) \
         .withColumn("VERSION_NUM", F.lit(2)) \
         .withColumn("CHANGE_INFO", F.lit("Changed").cast("string")) \
         .withColumn("DW_INSERT_DT", F.current_timestamp()) \
         .withColumn("DW_UPDATE_DT", F.current_timestamp())

        # Unchanged active records
        df_unchanged = df_active.join(
            df_changed_keys, on=business_key, how="left_anti"
        )

        # Historical records already expired
        df_history = df_target.filter(
            F.col("END_EFFECTIVE_DATE") != F.lit("2099-12-31").cast("timestamp")
        )

        new_count = df_new.count()
        changed_count = df_changed_keys.count()

        # Combine all records
        df_final = df_unchanged \
            .unionByName(df_to_expire, allowMissingColumns=True) \
            .unionByName(df_history, allowMissingColumns=True) \
            .unionByName(df_new_version, allowMissingColumns=True) \
            .unionByName(df_new, allowMissingColumns=True)

        # Truncate first to keep SK identity intact then append
        conn3 = spark._jvm.java.sql.DriverManager.getConnection(
            jdbc_url,
            jdbc_props["user"],
            jdbc_props["password"]
        )
        stmt3 = conn3.createStatement()
        stmt3.execute(f"TRUNCATE TABLE {target_table}")
        stmt3.close()
        conn3.close()

        df_final.write.jdbc(
            url=jdbc_url,
            table=target_table,
            mode="append",
            properties=jdbc_props
        )

        print(f"{target_table} — New: {new_count}, Changed: {changed_count}")

# COMMAND ----------

# TBL_DIM_ORDER_METHOD_LKP — SCD1
df_source = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.ORDER_METHOD",
    properties=jdbc_props
).select("METHOD_CODE", "METHOD_NAME")

scd1_load(df_source, "integration.TBL_DIM_ORDER_METHOD_LKP", "METHOD_CODE")

# COMMAND ----------

# TBL_DIM_RETURN_REASON_LKP — SCD1
df_source = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.RETURN_REASON",
    properties=jdbc_props
).select("RETURN_REASON_CODE", "RETURN_REASON_DESC")

scd1_load(df_source, "integration.TBL_DIM_RETURN_REASON_LKP", "RETURN_REASON_CODE")

# COMMAND ----------

# TBL_DIM_COUNTRY_LKP — SCD1
df_source = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.COUNTRY",
    properties=jdbc_props
).select("COUNTRY_CODE", "COUNTRY_ID", "COUNTRY_NAME")

scd1_load(df_source, "integration.TBL_DIM_COUNTRY_LKP", "COUNTRY_CODE")

# COMMAND ----------

# TBL_DIM_WAREHOUSE_LKP — SCD1
df_source = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.WAREHOUSE",
    properties=jdbc_props
).select("BRANCH_CODE", "ADDRESS", "CITY", "POSTAL_CODE", "COUNTRY_CODE", "WAREHOUSE_BRANCH_CODE")

scd1_load(df_source, "integration.TBL_DIM_WAREHOUSE_LKP", "BRANCH_CODE")

# COMMAND ----------

# TBL_DIM_RETAILER_LKP — SCD1
df_source = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.RETAILER",
    properties=jdbc_props
).select("RETAILER_NAME", "RETAILER_SITE_CODE", "RETAILER_CONTACT_CODE")

scd1_load(df_source, "integration.TBL_DIM_RETAILER_LKP", "RETAILER_SITE_CODE")

# COMMAND ----------

# TBL_DIM_PRODUCT_NAME_LKP — SCD1
df_source = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.PRODUCT_NAME",
    properties=jdbc_props
).select("PRODUCT_NUMBER", "PRODUCT_NAME", "PRODUCT_DESCRIPTION")

scd1_load(df_source, "integration.TBL_DIM_PRODUCT_NAME_LKP", "PRODUCT_NUMBER")

# COMMAND ----------

# TBL_DIM_PRODUCT — SCD1
df_source = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.PRODUCT",
    properties=jdbc_props
).select(
    "PRODUCT_NUMBER", "BASE_PRODUCT_NUMBER", "INTRODUCTION_DATE",
    "DISCONTINUED_DATE", "PRODUCT_TYPE_CODE", "PRODUCT_COLOR_CODE",
    "PRODUCT_SIZE_CODE", "PRODUCT_BRAND_CODE", "PRODUCTION_COST",
    "GROSS_MARGIN", "PRODUCT_IMAGE"
)

scd1_load(df_source, "integration.TBL_DIM_PRODUCT", "PRODUCT_NUMBER")

# COMMAND ----------

# TBL_DIM_ORDER — SCD2
df_source = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.ORDER_HEADER",
    properties=jdbc_props
).select(
    "ORDER_NUMBER", "RETAILER_NAME", "RETAILER_SITE_CODE",
    "RETAILER_CONTACT_CODE", "SALES_STAFF_CODE", "SALES_BRANCH_CODE",
    "ORDER_DATE", "ORDER_CLOSE_DATE", "ORDER_METHOD_CODE"
)

compare_cols = [
    "RETAILER_NAME", "RETAILER_SITE_CODE", "RETAILER_CONTACT_CODE",
    "SALES_STAFF_CODE", "SALES_BRANCH_CODE", "ORDER_DATE",
    "ORDER_CLOSE_DATE", "ORDER_METHOD_CODE"
]

scd2_load(df_source, "integration.TBL_DIM_ORDER", "ORDER_NUMBER", compare_cols)

# COMMAND ----------

# TBL_FACT_SALES
df_orders = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.ORDER_DETAILS",
    properties=jdbc_props
)

df_dim_order = spark.read.jdbc(
    url=jdbc_url,
    table="integration.TBL_DIM_ORDER",
    properties=jdbc_props
).select("DIM_ORDER_SK", "ORDER_NUMBER") \
 .filter(F.col("END_EFFECTIVE_DATE") == F.lit("2099-12-31").cast("timestamp"))

df_dim_product = spark.read.jdbc(
    url=jdbc_url,
    table="integration.TBL_DIM_PRODUCT",
    properties=jdbc_props
).select("DIM_PRODUCT_SK", "PRODUCT_NUMBER") \
 .filter(F.col("END_EFFECTIVE_DATE") == F.lit("2099-12-31").cast("timestamp"))

df_dim_method = spark.read.jdbc(
    url=jdbc_url,
    table="integration.TBL_DIM_ORDER_METHOD_LKP",
    properties=jdbc_props
).select("DIM_ORDER_METHOD_SK", "METHOD_CODE")

df_dim_retailer = spark.read.jdbc(
    url=jdbc_url,
    table="integration.TBL_DIM_RETAILER_LKP",
    properties=jdbc_props
).select("DIM_RETAILER_SK", "RETAILER_SITE_CODE")

df_header = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.ORDER_HEADER",
    properties=jdbc_props
).select("ORDER_NUMBER", "RETAILER_SITE_CODE", "ORDER_METHOD_CODE")

# Join ORDER_DETAILS with header to get method and retailer
df_fact = df_orders.join(df_header, on="ORDER_NUMBER", how="left")

# Join with dimension tables to get SKs
df_fact = df_fact.join(df_dim_order, on="ORDER_NUMBER", how="left")
df_fact = df_fact.join(df_dim_product, on="PRODUCT_NUMBER", how="left")
df_fact = df_fact.join(df_dim_method, df_fact["ORDER_METHOD_CODE"] == df_dim_method["METHOD_CODE"], how="left")
df_fact = df_fact.join(df_dim_retailer, on="RETAILER_SITE_CODE", how="left")

# Select fact columns
df_fact_final = df_fact.select(
    "ORDER_NUMBER", "ORDER_DETAIL_CODE",
    "DIM_ORDER_SK", "DIM_PRODUCT_SK",
    "DIM_ORDER_METHOD_SK", "DIM_RETAILER_SK",
    "QUANTITY", "UNIT_COST", "UNIT_PRICE", "UNIT_SALE_PRICE"
).withColumn("DW_INSERT_DT", F.current_timestamp())

# Write to fact table — INSERT only
fact_count = df_fact_final.count()
df_fact_final.write.jdbc(
    url=jdbc_url,
    table="integration.TBL_FACT_SALES",
    mode="append",
    properties=jdbc_props
)

print(f"TBL_FACT_SALES — Inserted: {fact_count}")

# COMMAND ----------

# TBL_FACT_INVENTORY
df_inventory = spark.read.jdbc(
    url=jdbc_url,
    table="ingestion.INVENTORY_LEVELS",
    properties=jdbc_props
)

df_dim_product = spark.read.jdbc(
    url=jdbc_url,
    table="integration.TBL_DIM_PRODUCT",
    properties=jdbc_props
).select("DIM_PRODUCT_SK", "PRODUCT_NUMBER") \
 .filter(F.col("END_EFFECTIVE_DATE") == F.lit("2099-12-31").cast("timestamp"))

df_dim_warehouse = spark.read.jdbc(
    url=jdbc_url,
    table="integration.TBL_DIM_WAREHOUSE_LKP",
    properties=jdbc_props
).select("DIM_WAREHOUSE_SK", "WAREHOUSE_BRANCH_CODE")

# Join with dimension tables
df_fact = df_inventory \
    .join(df_dim_product, on="PRODUCT_NUMBER", how="left") \
    .join(df_dim_warehouse, on="WAREHOUSE_BRANCH_CODE", how="left")

# Select fact columns
df_fact_final = df_fact.select(
    "WAREHOUSE_BRANCH_CODE", "PRODUCT_NUMBER",
    "DIM_PRODUCT_SK", "DIM_WAREHOUSE_SK",
    "INVENTORY_YEAR", "INVENTORY_MONTH",
    "OPENING_INVENTORY", "CLOSING_INVENTORY"
).withColumn("DW_INSERT_DT", F.current_timestamp())

# Write to fact table — INSERT only
fact_count = df_fact_final.count()
df_fact_final.write.jdbc(
    url=jdbc_url,
    table="integration.TBL_FACT_INVENTORY",
    mode="append",
    properties=jdbc_props
)

print(f"TBL_FACT_INVENTORY — Inserted: {fact_count}")

# COMMAND ----------

