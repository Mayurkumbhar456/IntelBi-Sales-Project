# Databricks notebook source

spark.conf.set(
    "fs.azure.account.key.adlssalesprojectmk.dfs.core.windows.net",
    "BnXXyx9cM7zzuxKIJlG61xqTEDLlH9FbUU169T0qEPk0qWvYYkNarxvniuxWFXFZQb1w8LAfzAYy+AStFRbHUw=="
)

# ADLS Base Path
raw_base_path = "abfss://raw@adlssalesprojectmk.dfs.core.windows.net"

# COMMAND ----------


adls_path = "abfss://raw@adlssalesprojectmk.dfs.core.windows.net/"

# Set storage account key as Spark config
spark.conf.set(
    "fs.azure.account.key.adlssalesprojectmk.dfs.core.windows.net",
    "BnXXyx9cM7zzuxKIJlG61xqTEDLlH9FbUU169T0qEPk0qWvYYkNarxvniuxWFXFZQb1w8LAfzAYy+AStFRbHUw=="
)

# Test - list files in RAW container
display(dbutils.fs.ls("abfss://raw@adlssalesprojectmk.dfs.core.windows.net/"))