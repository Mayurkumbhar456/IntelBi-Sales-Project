# Databricks notebook source
# ADLS Storage Config
storage_account = "adlssalesprojectmk"
storage_key = "BnXXyx9cM7zzuxKIJlG61xqTEDLlH9FbUU169T0qEPk0qWvYYkNarxvniuxWFXFZQb1w8LAfzAYy+AStFRbHUw=="

spark.conf.set(
    f"fs.azure.account.key.{storage_account}.dfs.core.windows.net",
    storage_key
)

# Base paths
raw_base    = f"abfss://raw@{storage_account}.dfs.core.windows.net"
sql_target  = f"{raw_base}/SQLSource/Target"
sql_archive = f"{raw_base}/SQLSource/Archive"
sql_reject  = f"{raw_base}/SQLSource/Reject"
file_target  = f"{raw_base}/FileSource/Target"
file_archive = f"{raw_base}/FileSource/Archive"
file_reject  = f"{raw_base}/FileSource/Reject"

print("RAW SQL Target  :", sql_target)
print("RAW File Target :", file_target)

# COMMAND ----------

# Azure SQL DB Config
sql_server   = "sqlserver-salesproject-mk.database.windows.net"
sql_database = "ASQL-SalesProject-MK"
sql_user     = "sqladminmk"
sql_password = "Mayur@29"

jdbc_url = (
    f"jdbc:sqlserver://{sql_server}:1433;"
    f"database={sql_database};"
    f"encrypt=true;"
    f"trustServerCertificate=false;"
    f"hostNameInCertificate=*.database.windows.net;"
    f"loginTimeout=30;"
)

jdbc_props = {
    "user": sql_user,
    "password": sql_password,
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}

print("JDBC URL :", jdbc_url)
print("✅ SQL Config ready!")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from datetime import datetime

def get_latest_file(folder_path):
    try:
        files = dbutils.fs.ls(folder_path)
        if not files:
            return None
        latest = sorted(files, key=lambda f: f.modificationTime, reverse=True)[0]
        return latest.path
    except Exception as e:
        return None

def move_to_archive(file_path, archive_base, table_name):
    try:
        file_name = file_path.split("/")[-1]
        archive_path = f"{archive_base}/{table_name}/{file_name}"
        dbutils.fs.mv(file_path, archive_path)
    except Exception as e:
        pass

def save_rejects(reject_df, reject_base, table_name):
    count = reject_df.count()
    if count > 0:
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        reject_path = f"{reject_base}/{table_name}/Reject_{table_name}_{timestamp}"
        reject_df.write.mode("overwrite").parquet(reject_path)

def add_audit_cols(df):
    now = F.current_timestamp()
    return df.withColumn("DW_INSERT_DT", now).withColumn("DW_UPDATE_DT", now)

# COMMAND ----------

# ORDER_HEADER — INCREMENTAL
table_name = "ORDER_HEADER"

# Find latest file
all_files = dbutils.fs.ls(sql_target)
table_files = [f for f in all_files if table_name in f.name and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Validation 1 — Reject null ORDER_NUMBER
    df_reject_null = df_raw.filter(F.col("ORDER_NUMBER").isNull())
    df_valid = df_raw.filter(F.col("ORDER_NUMBER").isNotNull())

    # Validation 2 — Reject duplicate ORDER_NUMBER
    window = Window.partitionBy("ORDER_NUMBER").orderBy("ORDER_NUMBER")
    df_valid = df_valid.withColumn("rn", F.row_number().over(window))
    df_reject_dup = df_valid.filter(F.col("rn") > 1)
    df_valid = df_valid.filter(F.col("rn") == 1).drop("rn")

    # Validation 3 — Reject null RETAILER_NAME
    df_reject_retailer = df_valid.filter(F.col("RETAILER_NAME").isNull())
    df_valid = df_valid.filter(F.col("RETAILER_NAME").isNotNull())

    # Validation 4 — Reject null ORDER_DATE
    df_reject_date = df_valid.filter(F.col("ORDER_DATE").isNull())
    df_valid = df_valid.filter(F.col("ORDER_DATE").isNotNull())

    # Combine rejects
    cols = df_raw.columns
    df_rejects = df_reject_null.select(cols) \
        .union(df_reject_dup.select(cols)) \
        .union(df_reject_retailer.select(cols)) \
        .union(df_reject_date.select(cols))

    # Select only ingestion table columns
    ingestion_cols = [
        "ORDER_NUMBER", "RETAILER_NAME", "RETAILER_NAME_MB",
        "RETAILER_SITE_CODE", "RETAILER_CONTACT_CODE",
        "RAW_STAFF_CODE", "RAW_BRANCH_CODE",
        "ORDER_DATE", "ORDER_CLOSE_DATE", "ORDER_METHOD_CODE"
    ]
    available_cols = [c for c in ingestion_cols if c in df_valid.columns]
    df_valid = df_valid.select(available_cols)

    # Count
    valid_count  = df_valid.count()
    reject_count = df_rejects.count()

    # Save rejects
    save_rejects(df_rejects, sql_reject, table_name)

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("SQL")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.ORDER_HEADER",
        mode="append",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, sql_archive, table_name)

    print(f"ORDER_HEADER — Valid: {valid_count}, Rejected: {reject_count}")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# ORDER_DETAILS — INCREMENTAL
table_name = "ORDER_DETAILS"

# Find latest file
all_files = dbutils.fs.ls(sql_target)
table_files = [f for f in all_files if table_name in f.name and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Validation 1 — Reject null ORDER_DETAIL_CODE
    df_reject_null = df_raw.filter(F.col("ORDER_DETAIL_CODE").isNull())
    df_valid = df_raw.filter(F.col("ORDER_DETAIL_CODE").isNotNull())

    # Validation 2 — Reject duplicate ORDER_DETAIL_CODE
    window = Window.partitionBy("ORDER_DETAIL_CODE").orderBy("ORDER_DETAIL_CODE")
    df_valid = df_valid.withColumn("rn", F.row_number().over(window))
    df_reject_dup = df_valid.filter(F.col("rn") > 1)
    df_valid = df_valid.filter(F.col("rn") == 1).drop("rn")

    # Validation 3 — Reject null/zero/negative QUANTITY
    df_reject_qty = df_valid.filter(
        F.col("QUANTITY").isNull() | (F.col("QUANTITY") <= 0)
    )
    df_valid = df_valid.filter(
        F.col("QUANTITY").isNotNull() & (F.col("QUANTITY") > 0)
    )

    # Validation 4 — Reject null/zero/negative UNIT_COST
    df_reject_cost = df_valid.filter(
        F.col("UNIT_COST").isNull() | (F.col("UNIT_COST") <= 0)
    )
    df_valid = df_valid.filter(
        F.col("UNIT_COST").isNotNull() & (F.col("UNIT_COST") > 0)
    )

    # Validation 5 — Reject null/zero/negative UNIT_PRICE
    df_reject_price = df_valid.filter(
        F.col("UNIT_PRICE").isNull() | (F.col("UNIT_PRICE") <= 0)
    )
    df_valid = df_valid.filter(
        F.col("UNIT_PRICE").isNotNull() & (F.col("UNIT_PRICE") > 0)
    )

    # Combine rejects
    cols = df_raw.columns
    df_rejects = df_reject_null.select(cols) \
        .union(df_reject_dup.select(cols)) \
        .union(df_reject_qty.select(cols)) \
        .union(df_reject_cost.select(cols)) \
        .union(df_reject_price.select(cols))

    # Select ingestion columns
    ingestion_cols = [
        "ORDER_DETAIL_CODE", "ORDER_NUMBER", "SHIP_DATE",
        "PRODUCT_NUMBER", "PROMOTION_CODE", "QUANTITY",
        "UNIT_COST", "UNIT_PRICE", "UNIT_SALE_PRICE"
    ]
    available_cols = [c for c in ingestion_cols if c in df_valid.columns]
    df_valid = df_valid.select(available_cols)

    # Count
    valid_count  = df_valid.count()
    reject_count = df_rejects.count()

    # Save rejects
    save_rejects(df_rejects, sql_reject, table_name)

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("SQL")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.ORDER_DETAILS",
        mode="append",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, sql_archive, table_name)

    print(f"ORDER_DETAILS — Valid: {valid_count}, Rejected: {reject_count}")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# PRODUCT — FULL LOAD
table_name = "PRODUCT"

# Find latest file
all_files = dbutils.fs.ls(sql_target)
table_files = [f for f in all_files if table_name in f.name and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Validation 1 — Reject null PRODUCT_NUMBER
    df_reject_null = df_raw.filter(F.col("PRODUCT_NUMBER").isNull())
    df_valid = df_raw.filter(F.col("PRODUCT_NUMBER").isNotNull())

    # Validation 2 — Reject duplicate PRODUCT_NUMBER
    window = Window.partitionBy("PRODUCT_NUMBER").orderBy("PRODUCT_NUMBER")
    df_valid = df_valid.withColumn("rn", F.row_number().over(window))
    df_reject_dup = df_valid.filter(F.col("rn") > 1)
    df_valid = df_valid.filter(F.col("rn") == 1).drop("rn")

    # Combine rejects
    cols = df_raw.columns
    df_rejects = df_reject_null.select(cols) \
        .union(df_reject_dup.select(cols))

    # Select ingestion columns
    ingestion_cols = [
        "PRODUCT_NUMBER", "BASE_PRODUCT_NUMBER", "INTRODUCTION_DATE",
        "DISCONTINUED_DATE", "PRODUCT_TYPE_CODE", "PRODUCT_COLOR_CODE",
        "PRODUCT_SIZE_CODE", "PRODUCT_BRAND_CODE", "PRODUCTION_COST",
        "GROSS_MARGIN", "PRODUCT_IMAGE"
    ]
    available_cols = [c for c in ingestion_cols if c in df_valid.columns]
    df_valid = df_valid.select(available_cols)

    # Count
    valid_count  = df_valid.count()
    reject_count = df_rejects.count()

    # Save rejects
    save_rejects(df_rejects, sql_reject, table_name)

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("SQL")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.PRODUCT",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, sql_archive, table_name)

    print(f"PRODUCT — Valid: {valid_count}, Rejected: {reject_count}")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# BRANCH — FULL LOAD
table_name = "BRANCH"

# Find latest file
all_files = dbutils.fs.ls(sql_target)
table_files = [f for f in all_files if table_name in f.name and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # No validations for BRANCH — pass through
    df_valid = df_raw

    # Select ingestion columns
    ingestion_cols = [
        "BRANCH_CODE", "ADDRESS1", "ADDRESS2", "CITY",
        "REGION_CODE", "COUNTRY_CODE", "POSTAL_ZONE",
        "MANAGER_CODE", "BRANCH_TYPE_CODE", "BRANCH_CLASS_CODE",
        "FAX", "TELEPHONE", "START_DATE", "END_DATE",
        "WAREHOUSE_BRANCH_FLG"
    ]
    available_cols = [c for c in ingestion_cols if c in df_valid.columns]
    df_valid = df_valid.select(available_cols)

    # Count
    valid_count = df_valid.count()

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("SQL")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.BRANCH",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, sql_archive, table_name)

    print(f"BRANCH — Valid: {valid_count}, Rejected: 0")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# RETURN_ITEM — FULL LOAD
table_name = "RETURN_ITEM"

# Find latest file
all_files = dbutils.fs.ls(sql_target)
table_files = [f for f in all_files if table_name in f.name and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Validation 1 — Reject null RETURN_CODE
    df_reject_null = df_raw.filter(F.col("RETURN_CODE").isNull())
    df_valid = df_raw.filter(F.col("RETURN_CODE").isNotNull())

    # Validation 2 — Reject duplicate RETURN_CODE
    window = Window.partitionBy("RETURN_CODE").orderBy("RETURN_CODE")
    df_valid = df_valid.withColumn("rn", F.row_number().over(window))
    df_reject_dup = df_valid.filter(F.col("rn") > 1)
    df_valid = df_valid.filter(F.col("rn") == 1).drop("rn")

    # Combine rejects
    cols = df_raw.columns
    df_rejects = df_reject_null.select(cols) \
        .union(df_reject_dup.select(cols))

    # Select ingestion columns
    ingestion_cols = [
        "RETURN_CODE", "RETURN_DATE", "ORDER_DETAIL_CODE",
        "RETURN_REASON_CODE", "RETURN_QUANTITY", "ASSIGNED_TO",
        "FOLLOW_UP_CODE", "COMMENTS", "DATE_ADVISED"
    ]
    available_cols = [c for c in ingestion_cols if c in df_valid.columns]
    df_valid = df_valid.select(available_cols)

    # Count
    valid_count  = df_valid.count()
    reject_count = df_rejects.count()

    # Save rejects
    save_rejects(df_rejects, sql_reject, table_name)

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("SQL")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.RETURN_ITEM",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, sql_archive, table_name)

    print(f"RETURN_ITEM — Valid: {valid_count}, Rejected: {reject_count}")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# INVENTORY_LEVELS — FULL LOAD
table_name = "INVENTORY_LEVELS"

# Find latest file
all_files = dbutils.fs.ls(sql_target)
table_files = [f for f in all_files if table_name in f.name and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Validation 1 — Reject null INVENTORY_YEAR
    df_reject_null = df_raw.filter(F.col("INVENTORY_YEAR").isNull())
    df_valid = df_raw.filter(F.col("INVENTORY_YEAR").isNotNull())

    # Combine rejects
    cols = df_raw.columns
    df_rejects = df_reject_null.select(cols)

    # Select ingestion columns
    ingestion_cols = [
        "INVENTORY_YEAR", "INVENTORY_MONTH", "WAREHOUSE_BRANCH_CODE",
        "PRODUCT_NUMBER", "OPENING_INVENTORY", "QUANTITY_SHIPPED",
        "ADDITIONS", "UNIT_COST", "CLOSING_INVENTORY", "AVERAGE_UNIT_COST"
    ]
    available_cols = [c for c in ingestion_cols if c in df_valid.columns]
    df_valid = df_valid.select(available_cols)

    # Count
    valid_count  = df_valid.count()
    reject_count = df_rejects.count()

    # Save rejects
    save_rejects(df_rejects, sql_reject, table_name)

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("SQL")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.INVENTORY_LEVELS",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, sql_archive, table_name)

    print(f"INVENTORY_LEVELS — Valid: {valid_count}, Rejected: {reject_count}")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# ORDER_METHOD — FULL LOAD (Flat File)
table_name = "ORDER_METHOD"

# Find latest file
all_files = dbutils.fs.ls(file_target)
table_files = [f for f in all_files if table_name in f.name.upper() and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Column rename as per LLD
    df_valid = df_raw \
        .withColumnRenamed("ORDER_METHOD_CODE", "METHOD_CODE") \
        .withColumnRenamed("ORDER_METHOD_EN", "METHOD_NAME")

    # Select ingestion columns
    df_valid = df_valid.select("METHOD_CODE", "METHOD_NAME")

    # Count
    valid_count = df_valid.count()

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("LKP File")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.ORDER_METHOD",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, file_archive, table_name)

    print(f"ORDER_METHOD — Valid: {valid_count}, Rejected: 0")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# RETURN_REASON — FULL LOAD (Flat File)
table_name = "RETURN_REASON"

# Find latest file
all_files = dbutils.fs.ls(file_target)
table_files = [f for f in all_files if table_name in f.name.upper() and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Column rename as per LLD
    df_valid = df_raw \
        .withColumnRenamed("REASON_DESCRIPTION_EN", "RETURN_REASON_DESC")

    # Select ingestion columns
    df_valid = df_valid.select("RETURN_REASON_CODE", "RETURN_REASON_DESC")

    # Count
    valid_count = df_valid.count()

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("LKP File")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.RETURN_REASON",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, file_archive, table_name)

    print(f"RETURN_REASON — Valid: {valid_count}, Rejected: 0")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# COUNTRY — FULL LOAD (Flat File)
table_name = "COUNTRY"

# Find latest file
all_files = dbutils.fs.ls(file_target)
table_files = [f for f in all_files if table_name in f.name.upper() and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV — pipe delimited
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .option("delimiter", "|") \
        .csv(file_path)

    # Pass through — no validations
    df_valid = df_raw.select("COUNTRY_CODE", "COUNTRY_ID", "COUNTRY_NAME")

    # Count
    valid_count = df_valid.count()

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("LKP File")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.COUNTRY",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, file_archive, table_name)

    print(f"COUNTRY — Valid: {valid_count}, Rejected: 0")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# WAREHOUSE — FULL LOAD (Flat File)
table_name = "WAREHOUSE"

# Find latest file
all_files = dbutils.fs.ls(file_target)
table_files = [f for f in all_files if table_name in f.name.upper() and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV — tab delimited
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .option("delimiter", "\t") \
        .csv(file_path)

    # Column rename as per LLD
    df_valid = df_raw \
        .withColumnRenamed("ADDRESS1", "ADDRESS") \
        .withColumnRenamed("POSTAL_ZONE", "POSTAL_CODE")

    # Select ingestion columns
    df_valid = df_valid.select(
        "BRANCH_CODE", "ADDRESS", "CITY",
        "POSTAL_CODE", "COUNTRY_CODE", "WAREHOUSE_BRANCH_CODE"
    )

    # Count
    valid_count = df_valid.count()

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("LKP File")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.WAREHOUSE",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, file_archive, table_name)

    print(f"WAREHOUSE — Valid: {valid_count}, Rejected: 0")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# RETAILER — FULL LOAD (Flat File)
table_name = "RETAILER"

# Find latest file
all_files = dbutils.fs.ls(file_target)
table_files = [f for f in all_files if table_name in f.name.upper() and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Pass through — no validations
    df_valid = df_raw.select(
        "RETAILER_NAME", "RETAILER_SITE_CODE", "RETAILER_CONTACT_CODE"
    )

    # Count
    valid_count = df_valid.count()

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("LKP File")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.RETAILER",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, file_archive, table_name)

    print(f"RETAILER — Valid: {valid_count}, Rejected: 0")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

# PRODUCT_NAME — FULL LOAD (Flat File)
table_name = "PRODUCT_NAME"

# Find latest file — file is named PRODUCT_NAME_LOOKUP
all_files = dbutils.fs.ls(file_target)
table_files = [f for f in all_files if "PRODUCT_NAME" in f.name.upper() and f.name.endswith(".csv")]

if table_files:
    file_path = sorted(table_files, key=lambda f: f.modificationTime, reverse=True)[0].path

    # Read CSV
    df_raw = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(file_path)

    # Filter English only — PRODUCT_LANGUAGE = 'EN'
    df_valid = df_raw.filter(F.col("PRODUCT_LANGUAGE") == "EN")

    # Select ingestion columns
    df_valid = df_valid.select(
        "PRODUCT_NUMBER", "PRODUCT_NAME", "PRODUCT_DESCRIPTION"
    )

    # Count
    valid_count = df_valid.count()

    # Add audit columns
    df_final = df_valid \
        .withColumn("SOURCE_ID", F.lit("LKP File")) \
        .withColumn("DataDate", F.current_date()) \
        .withColumn("UpdateDate", F.current_date()) \
        .withColumn("DW_INSERT_DT", F.current_timestamp()) \
        .withColumn("DW_UPDATE_DT", F.current_timestamp())

    # Write to ingestion — TRUNCATE and LOAD
    df_final.write.jdbc(
        url=jdbc_url,
        table="ingestion.PRODUCT_NAME",
        mode="overwrite",
        properties=jdbc_props
    )

    # Archive source file
    move_to_archive(file_path, file_archive, table_name)

    print(f"PRODUCT_NAME — Valid: {valid_count}, Rejected: 0")

else:
    print(f"No file found for {table_name}")

# COMMAND ----------

